Justice AI — v0.1.0 Preview
============================
Platform: Windows 10 / 11 (x64)

Thank you for downloading Justice AI.

This is an early preview placeholder. The full Windows application
is currently in active development.

When released, this package will contain:
  - JusticeAI-Setup.exe  (Windows installer)
  - Ollama setup guide
  - Model installation instructions

What to expect in the full release:
  - 100% local execution — no data ever leaves your machine
  - RAG pipeline over your own legal documents (PDF, DOCX)
  - Citation-first answers with filename + page number
  - Encrypted local chat history
  - Works fully offline after initial model download

Follow development:
  https://github.com/lastbaa/CS-370-Justice-AI-Project

Requirements (full release):
  - Windows 10 or Windows 11, 64-bit
  - 16 GB RAM recommended (8 GB minimum)
  - ~8 GB free storage for model files
  - Ollama installed (https://ollama.ai)

--
Justice AI — Privacy-first legal research for professionals.
Not legal advice. A research tool for the attorneys who give it.
