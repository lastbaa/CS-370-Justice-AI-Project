Justice AI — v0.1.0 Preview
============================
Platform: macOS (Apple Silicon + Intel Universal)

Thank you for downloading Justice AI.

This is an early preview placeholder. The full macOS application
is currently in active development.

When released, this package will contain:
  - JusticeAI.app  (macOS desktop application)
  - Ollama setup guide
  - Model installation instructions

What to expect in the full release:
  - 100% local execution — no data ever leaves your machine
  - RAG pipeline over your own legal documents (PDF, DOCX)
  - Citation-first answers with filename + page number
  - Encrypted local chat history
  - Works fully offline after initial model download

Follow development:
  https://github.com/lastbaa/CS-370-Justice-AI-Project

Requirements (full release):
  - macOS 12 Monterey or later
  - Apple Silicon (M1/M2/M3) or Intel
  - 16 GB RAM recommended (8 GB minimum)
  - ~8 GB free storage for model files
  - Ollama installed (https://ollama.ai)

--
Justice AI — Privacy-first legal research for professionals.
Not legal advice. A research tool for the attorneys who give it.
