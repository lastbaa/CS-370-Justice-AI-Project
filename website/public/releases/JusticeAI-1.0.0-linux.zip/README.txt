Justice AI — v0.1.0 Preview
============================
Platform: Linux (x86_64 AppImage)

Thank you for downloading Justice AI.

This is an early preview placeholder. The full Linux application
is currently in active development.

When released, this package will contain:
  - JusticeAI-1.0.0.AppImage  (portable Linux app, no install needed)
  - Ollama setup guide
  - Model installation instructions

What to expect in the full release:
  - 100% local execution — no data ever leaves your machine
  - RAG pipeline over your own legal documents (PDF, DOCX)
  - Citation-first answers with filename + page number
  - Encrypted local chat history
  - Works fully offline after initial model download

To run an AppImage:
  chmod +x JusticeAI-1.0.0.AppImage
  ./JusticeAI-1.0.0.AppImage

Follow development:
  https://github.com/lastbaa/CS-370-Justice-AI-Project

Requirements (full release):
  - Any modern x86_64 Linux distribution
  - 16 GB RAM recommended (8 GB minimum)
  - ~8 GB free storage for model files
  - Ollama installed (https://ollama.ai)
  - FUSE 2 (for AppImage support)

--
Justice AI — Privacy-first legal research for professionals.
Not legal advice. A research tool for the attorneys who give it.
